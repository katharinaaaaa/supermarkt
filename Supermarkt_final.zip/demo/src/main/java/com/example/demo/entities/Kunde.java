package com.example.demo.entities;

public class Kunde {
	
	private String kunden_nummer;
	private String kunden_name;
	private String kunden_email;
	private String kunden_adresse;
	
	public String getKunden_nummer() {
		return kunden_nummer;
	}
	public String getKunden_name() {
		return kunden_name;
	}

	public String getKunden_email() {
		return kunden_email;
	}

	public String getKunden_adresse() {
		return kunden_adresse;
	}


}
