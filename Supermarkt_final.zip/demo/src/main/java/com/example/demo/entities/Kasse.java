package com.example.demo.entities;

public class Kasse {
	private String gesamtsumme;
	
	public Kasse() {
		gesamtsumme = "";
	}

	public String getGesamtsumme() {
		return gesamtsumme;
	}

	public void setGesamtsumme(String gesamtsumme) {
		this.gesamtsumme = gesamtsumme;
	}

}
